
package icetask6;

public class Teacher extends Person {
    private String subject;

    // Constructor
    public Teacher(String name, int age, String email, String subject) {
        
    // Call the constructor of the Person class
    super(name, age, email);
    this.subject = subject;
    }

    //This mmethod displays the teacher information
    public void displayTeacherInfo() {
    
    // Call the displayInfo() method from Person class
    super.displayInfo();
    System.out.println("Subject: " + subject);
    }

    // Getter and setter for subject 
    public String getSubject() {
    return subject;
    }

    public void setSubject(String subject) {
    this.subject = subject;
    }}