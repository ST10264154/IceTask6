
package icetask6;


public class Main {
    public static void main(String[] args) {
       
    Student student = new Student("Peter Parker", 17, "pparker@gmail.com", "S12345789");
        
    Teacher teacher = new Teacher("Tony Stark", 39, "stark@outlook.com", "Robotics");

       
    System.out.println("********* Student Details ********* ");
    student.displayStudentInfo();  
    System.out.println();  
   
    System.out.println("*********  Teacher Details ********* ");
    teacher.displayTeacherInfo(); 
    System.out.println();
    }}

