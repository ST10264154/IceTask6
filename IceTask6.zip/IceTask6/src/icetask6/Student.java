
package icetask6;

public class Student extends Person {
    private String studentID;

    // Constructor
    public Student(String name, int age, String email, String studentID) {
        
    // Call the constructor of the Person class
    super(name, age, email);
    this.studentID = studentID;
    }

    // This mmethod displays the student information
    public void displayStudentInfo() {
        
    // Call the displayInfo() method from Person class
    super.displayInfo();
    System.out.println("Student ID: " + studentID);
    }

    // Getter and setter for studentID 
    public String getStudentID() {
    return studentID;
    }

    public void setStudentID(String studentID) {
    this.studentID = studentID;
    }}
